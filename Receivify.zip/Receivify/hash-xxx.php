<?php
echo password_hash("admin123", PASSWORD_DEFAULT);
?>


<!-- $2y$10$TGXMr/63ySloAkibPX8Qyu/2.orRMgi4/ugEQNmnFxQYRZvTli5.y -->

INSERT INTO users (username, password, role)
VALUES ('admin', '$2y$10$TGXMr/63ySloAkibPX8Qyu/2.orRMgi4/ugEQNmnFxQYRZvTli5.y', 'admin');
