<?php
// footer.php
?>
<footer>
    &copy; <?php echo date("Y"); ?> Receivify. All rights reserved.
</footer>
</body>
</html>
