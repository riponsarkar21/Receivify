<?php
$mysqli = new mysqli("localhost", "root", "", "receivify");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=receivify_export.xls");

$conn = new mysqli("localhost", "root", "", "receivify");
$result = $conn->query("SELECT * FROM entries");

echo "Event\tGuest\tMobile\tRelation\tAddress\tGift\tCash\tMode\tTime\n";
while ($row = $result->fetch_assoc()) {
    echo "{$row['event']}\t{$row['guest']}\t{$row['mobile']}\t{$row['relation']}\t{$row['address']}\t{$row['gift']}\t{$row['cash']}\t{$row['mode']}\t{$row['created_at']}\n";
}
?>
