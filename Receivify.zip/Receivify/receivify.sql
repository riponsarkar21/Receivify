-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2025 at 01:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `receivify`
--

-- --------------------------------------------------------

--
-- Table structure for table `entries`
--

CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `event` varchar(255) DEFAULT NULL,
  `guest` varchar(255) DEFAULT NULL,
  `gift` varchar(255) DEFAULT NULL,
  `cash` decimal(10,2) DEFAULT NULL,
  `mode` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `mobile` varchar(20) DEFAULT NULL,
  `relation` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `entries`
--

INSERT INTO `entries` (`id`, `event`, `guest`, `gift`, `cash`, `mode`, `created_at`, `mobile`, `relation`, `address`) VALUES
(1, 'Ripon Akhi Wedding', 'Ananda', '', 5000.00, 'In-person', '2025-06-12 18:36:55', NULL, NULL, NULL),
(2, 'Ripon Akhi Wedding', 'Chandana', '', 4000.00, 'Online', '2025-06-12 18:48:19', NULL, NULL, NULL),
(3, 'Ripon Akhi Wedding', 'Mukta', '', 10000.00, 'In-person', '2025-06-12 20:01:32', '01966951527', 'Sister', 'Jessore'),
(4, 'Ripon Akhi Wedding', 'Bipul', '', 3000.00, 'Proxy', '2025-06-12 21:28:11', '01234123456', 'Uncle', 'Khulna'),
(5, 'Ripon Akhi Wedding', 'Shohag', '', 5000.00, 'In-person', '2025-06-12 21:28:59', '01921157033', 'Friend', 'Bashunda'),
(6, 'Ripon Akhi Wedding', 'Sujon', '', 1000.00, 'In-person', '2025-06-12 22:04:13', '01911223344', 'Colleague', 'CTG'),
(7, 'Ripon Akhi Wedding', 'Sumon', '', 2000.00, 'In-person', '2025-06-12 22:04:53', '01711223344', 'Colleague', 'Dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','assistant') DEFAULT 'assistant'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(4, 'admin', '$2y$10$TGXMr/63ySloAkibPX8Qyu/2.orRMgi4/ugEQNmnFxQYRZvTli5.y', 'admin'),
(5, 'test1', '$2y$10$DKtb9wwtgWnmoVah9ZyW5OMTtviGhUNR7S9/UdusvaBpLlDTKgdWu', 'assistant');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `entries`
--
ALTER TABLE `entries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `entries`
--
ALTER TABLE `entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
