<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    die("Access denied. Admins only.");
}

$mysqli = new mysqli("localhost", "root", "", "receivify");

// Add user
if (isset($_POST['add'])) {
    $username = $_POST['new_username'];
    $password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $role = $_POST['new_role'];
    
    $stmt = $mysqli->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $password, $role);
    $stmt->execute();
}

// Delete user
if (isset($_GET['delete'])) {
    $del_user = $_GET['delete'];
    if ($del_user !== 'admin') { // Prevent deletion of primary admin
        $stmt = $mysqli->prepare("DELETE FROM users WHERE username = ?");
        $stmt->bind_param("s", $del_user);
        $stmt->execute();
    }
}

// Change role
if (isset($_POST['change_role'])) {
    $user = $_POST['user'];
    $new_role = $_POST['role'];
    $stmt = $mysqli->prepare("UPDATE users SET role = ? WHERE username = ?");
    $stmt->bind_param("ss", $new_role, $user);
    $stmt->execute();
}

// Fetch all users
$result = $mysqli->query("SELECT username, role FROM users ORDER BY username");
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Management - Receivify</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>User Management</h2>
<a href="index.php">← Back to Dashboard</a>

<table border="1">
    <tr><th>Username</th><th>Role</th><th>Change Role</th><th>Delete</th></tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= $row['role'] ?></td>
            <td>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="user" value="<?= $row['username'] ?>">
                    <select name="role">
                        <option value="admin" <?= $row['role']=='admin'?'selected':'' ?>>admin</option>
                        <option value="assistant" <?= $row['role']=='assistant'?'selected':'' ?>>assistant</option>
                    </select>
                    <button type="submit" name="change_role">Change</button>
                </form>
            </td>
            <td>
                <?php if ($row['username'] !== 'admin'): ?>
                    <a href="?delete=<?= $row['username'] ?>" onclick="return confirm('Delete user <?= $row['username'] ?>?')">Delete</a>
                <?php else: ?>
                    (protected)
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<h3>Add New User</h3>
<form method="post">
    <label>Username: <input type="text" name="new_username" required></label><br>
    <label>Password: <input type="password" name="new_password" required></label><br>
    <label>Role:
        <select name="new_role">
            <option value="assistant">assistant</option>
            <option value="admin">admin</option>
        </select>
    </label><br>
    <button type="submit" name="add">Add User</button>
</form>
</body>
</html>
