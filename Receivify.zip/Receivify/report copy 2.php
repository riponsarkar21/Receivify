<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "receivify");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receivify Report</title>
    <style>
        body { font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px; border: 1px solid #ccc; text-align: left; }
        th.sortable:hover { cursor: pointer; background: #eee; }

        .export-buttons, #filters, .date-range {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin: 10px 0;
        }

        .export-buttons button {
            padding: 8px 12px;
        }

        @media print {
            .export-buttons, #filters, .date-range {
                display: none !important;
            }
        }

        @media screen and (max-width: 600px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }
            thead tr { display: none; }
            td {
                position: relative;
                padding-left: 50%;
                text-align: right;
            }
            td::before {
                position: absolute;
                left: 10px;
                top: 8px;
                font-weight: bold;
                white-space: nowrap;
            }
            td:nth-of-type(1)::before { content: "Event"; }
            td:nth-of-type(2)::before { content: "Guest"; }
            td:nth-of-type(3)::before { content: "Mobile"; }
            td:nth-of-type(4)::before { content: "Relation"; }
            td:nth-of-type(5)::before { content: "Address"; }
            td:nth-of-type(6)::before { content: "Gift"; }
            td:nth-of-type(7)::before { content: "Cash"; }
            td:nth-of-type(8)::before { content: "Mode"; }
            td:nth-of-type(9)::before { content: "Time"; }
        }
    </style>
</head>
<body>

<h2 style="text-align:center">Gift/Cash Entries Report</h2>

<div id="filters">
    <input type="text" id="filterGuest" placeholder="Filter by guest name..." style="flex:1;">
    <select id="filterMode">
        <option value="">All Modes</option>
        <option value="In-person">In-person</option>
        <option value="Online">Online</option>
        <option value="Proxy">Proxy</option>
    </select>
    <select id="filterRelation">
        <option value="">All Relations</option>
        <?php
        $relations = $mysqli->query("SELECT DISTINCT relation FROM entries WHERE relation IS NOT NULL AND relation != '' ORDER BY relation ASC");
        while ($rel = $relations->fetch_assoc()) {
            $val = htmlspecialchars($rel['relation']);
            echo "<option value=\"$val\">$val</option>";
        }
        ?>
    </select>
    <input type="number" id="minCash" placeholder="Min cash">
    <input type="number" id="maxCash" placeholder="Max cash">
    <div class="date-range">
        <input type="date" id="startDate">
        <input type="date" id="endDate">
    </div>
</div>

<div class="export-buttons">
    <a href="export_excel.php" target="_blank"><button>Export to Excel</button></a>
    <a href="export_pdf.php" target="_blank"><button>Export to PDF</button></a>
    <button onclick="window.print()">Print</button>
</div>

<table id="entryTable">
    <thead>
    <tr>
        <th class="sortable">Event</th>
        <th class="sortable">Guest</th>
        <th>Mobile</th>
        <th>Relation</th>
        <th>Address</th>
        <th>Gift</th>
        <th class="sortable">Cash</th>
        <th>Mode</th>
        <th class="sortable">Time</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $total = 0;
    $res = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
    while ($row = $res->fetch_assoc()) {
        $total += $row['cash'];
        echo "<tr>";
        echo "<td>{$row['event']}</td>";
        echo "<td>{$row['guest']}</td>";
        echo "<td>{$row['mobile']}</td>";
        echo "<td>{$row['relation']}</td>";
        echo "<td>{$row['address']}</td>";
        echo "<td>{$row['gift']}</td>";
        echo "<td>{$row['cash']}</td>";
        echo "<td>{$row['mode']}</td>";
        echo "<td>{$row['created_at']}</td>";
        echo "</tr>";
    }
    ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="6" style="text-align:right;"><strong>Total Cash:</strong></td>
            <td colspan="3"><strong><?php echo number_format($total, 2); ?></strong></td>
        </tr>
    </tfoot>
</table>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function applyFilters() {
    let guest = $('#filterGuest').val().toLowerCase();
    let mode = $('#filterMode').val().toLowerCase();
    let relation = $('#filterRelation').val().toLowerCase();
    let minCash = parseFloat($('#minCash').val());
    let maxCash = parseFloat($('#maxCash').val());
    let start = $('#startDate').val();
    let end = $('#endDate').val();

    $('#entryTable tbody tr').each(function () {
        let row = $(this);
        let g = row.find('td:nth-child(2)').text().toLowerCase();
        let m = row.find('td:nth-child(8)').text().toLowerCase();
        let r = row.find('td:nth-child(4)').text().toLowerCase();
        let c = parseFloat(row.find('td:nth-child(7)').text()) || 0;
        let d = row.find('td:nth-child(9)').text().substr(0, 10);

        let show = true;
        if (guest && !g.includes(guest)) show = false;
        if (mode && m !== mode) show = false;
        if (relation && r !== relation) show = false;
        if (!isNaN(minCash) && c < minCash) show = false;
        if (!isNaN(maxCash) && c > maxCash) show = false;
        if (start && d < start) show = false;
        if (end && d > end) show = false;

        row.toggle(show);
    });
}

$('#filterGuest, #filterMode, #filterRelation, #minCash, #maxCash, #startDate, #endDate').on('input change', applyFilters);

// Sort columns
$('th.sortable').click(function () {
    const table = $(this).parents('table');
    const tbody = table.find('tbody');
    const index = $(this).index();
    const asc = !$(this).data('asc');
    $(this).data('asc', asc);

    const rows = tbody.find('tr').get().sort(function (a, b) {
        const A = $(a).children('td').eq(index).text().toUpperCase();
        const B = $(b).children('td').eq(index).text().toUpperCase();
        if ($.isNumeric(A) && $.isNumeric(B)) {
            return asc ? A - B : B - A;
        }
        return asc ? A.localeCompare(B) : B.localeCompare(A);
    });

    $.each(rows, function (i, row) {
        tbody.append(row);
    });
});
</script>

</body>
</html>
