<?php
$mysqli = new mysqli("localhost", "root", "", "receivify");

$id     = $_POST['id'];
$column = $_POST['column'];
$value  = $_POST['value'];

$allowed = ['guest', 'mobile', 'relation', 'address', 'gift', 'cash', 'mode'];
if (!in_array($column, $allowed)) {
    exit("Invalid column.");
}

$stmt = $mysqli->prepare("UPDATE entries SET $column = ? WHERE id = ?");
$stmt->bind_param("si", $value, $id);
$stmt->execute();
echo "Updated.";
?>
