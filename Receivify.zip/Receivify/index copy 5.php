<!-- Receivify - Event Gift/Cash Receiving Web App -->

<!-- File: index.php -->
<?php


// Start session and connect to DB
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$mysqli = new mysqli("localhost", "root", "", "receivify");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Receivify</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <h1>Receivify - Event Gift & Cash Tracker</h1>

    <?php if ($_SESSION['role'] === 'admin'): ?>
    <div style="text-align:right;">
        <a href="users.php">User Management</a>
    </div>
    <?php endif; ?>


        <div style="text-align:right;">
            Logged in as: <strong><?php echo $_SESSION['username']; ?></strong> |
            <a href="logout.php">Logout</a>
        </div>

    <div class="form-holder">
        <form action="add_entry.php" method="POST">
            <label>Event Name:
                <input type="text" name="event" value="Ripon Akhi Wedding" required>
            </label><br>

            <label>Guest Name:
                <input type="text" name="guest" required>
            </label><br>

            <label>Mobile Number:
                <input type="tel" name="mobile" pattern="[0-9]{11}" placeholder="e.g. 017xxxxxxxx" required>
            </label><br>

            <label>Relation:
                <input type="text" name="relation" placeholder="e.g. Cousin, Friend, Uncle">
            </label><br>

            <label>Address:
                <input type="text" name="address">
            </label><br>

            <label>Gift Description:
                <input type="text" name="gift">
            </label><br>

            <label>Cash Amount:
                <input type="number" name="cash" min="0">
            </label><br>

            <label>Mode of Giving:
                <select name="mode">
                    <option value="In-person">In-person</option>
                    <option value="Online">Online</option>
                    <option value="Proxy">Proxy</option>
                </select>
            </label><br>

            <button type="submit">Add Entry</button>
        </form>

    </div>

    <h2>Gift/Cash Entries</h2>
    <div style="text-align:right; margin: 10px 0;">
        <form action="export_excel.php" method="post" style="display:inline;">
            <button type="submit">Export to Excel</button>
        </form>
        <form action="export_pdf.php" method="post" style="display:inline;">
            <button type="submit">Export to PDF</button>
        </form>
    </div>

    <table border="1">
        <tr><th>Event</th><th>Guest</th><th>Gift</th><th>Cash</th><th>Mode</th><th>Time</th></tr>
        <?php
        $result = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>{$row['event']}</td>
                <td>{$row['guest']}</td>
                <td>{$row['gift']}</td>
                <td>{$row['cash']}</td>
                <td>{$row['mode']}</td>
                <td>{$row['created_at']}</td>
            </tr>";
        }
        ?>
    </table>
</body>
</html>