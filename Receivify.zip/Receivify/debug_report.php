<?php
$mysqli = new mysqli("localhost", "root", "", "receivify");
if ($mysqli->connect_error) die("Connection failed: " . $mysqli->connect_error);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Report - Receivify</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 8px; border: 1px solid #ccc; text-align: left; }
        th.sortable:hover { cursor: pointer; background: #f1f1f1; }
        th .sort-icon { font-size: 12px; margin-left: 4px; color: #888; }
        tr:nth-child(even) { background: #f9f9f9; }
        .filters, .summary { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 10px; }
        .filters input, .filters select, .summary span { padding: 6px; font-size: 14px; }
        .filter-controls { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .export-buttons button, .clear-filters-btn { padding: 8px 10px; margin-left: 5px; }
        @media print {
            .filters, .filter-controls, .export-buttons, .summary { display: none !important; }
            body { padding: 0; }
        }
        thead th { position: sticky; top: 0; background: #fff; z-index: 1; }
    </style>
</head>
<body>

<h2>Gift/Cash Report</h2>

<div class="filters">
    <input type="text" id="filterGuest" placeholder="Filter by guest name">
    <select id="filterMode">
        <option value="">All Modes</option>
        <option value="In-person">In-person</option>
        <option value="Online">Online</option>
        <option value="Proxy">Proxy</option>
    </select>
    <select id="filterRelation">
        <option value="">All Relations</option>
        <?php
        $res = $mysqli->query("SELECT DISTINCT relation FROM entries WHERE relation != ''");
        while ($r = $res->fetch_assoc()) {
            $val = htmlspecialchars($r['relation']);
            echo "<option value=\"$val\">$val</option>";
        }
        ?>
    </select>
    <input type="number" id="minCash" placeholder="Min cash" style="width: 90px;">
    <input type="number" id="maxCash" placeholder="Max cash" style="width: 90px;">
    <input type="date" id="startDate">
    <input type="date" id="endDate">
    <button class="clear-filters-btn" onclick="clearFilters()">Clear All Filters</button>
</div>

<div class="filter-controls">
    <div class="summary" id="filterSummary"></div>
    <div class="export-buttons">
        <a href="export_excel.php" target="_blank"><button>Excel</button></a>
        <a href="export_pdf.php" target="_blank"><button>PDF</button></a>
        <a href="export_csv.php" target="_blank"><button>CSV</button></a>
        <button onclick="window.print()">Print</button>
    </div>
</div>

<table id="entryTable">
    <thead>
        <tr>
            <th class="sortable" onclick="sortTable(0)">Event <span class="sort-icon"></span></th>
            <th class="sortable" onclick="sortTable(1)">Guest <span class="sort-icon"></span></th>
            <th>Mobile</th>
            <th>Relation</th>
            <th>Address</th>
            <th>Gift</th>
            <th class="sortable" onclick="sortTable(6)">Cash <span class="sort-icon"></span></th>
            <th>Mode</th>
            <th>Date</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $result = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
        $totalCash = 0;
        while ($row = $result->fetch_assoc()) {
            $totalCash += $row['cash'];
            echo "<tr>";
            echo "<td>{$row['event']}</td>";
            echo "<td>{$row['guest']}</td>";
            echo "<td>{$row['mobile']}</td>";
            echo "<td>{$row['relation']}</td>";
            echo "<td>{$row['address']}</td>";
            echo "<td>{$row['gift']}</td>";
            echo "<td class='cash'>" . number_format($row['cash'], 2) . "</td>";
            echo "<td>{$row['mode']}</td>";
            echo "<td>{$row['created_at']}</td>";
            echo "</tr>";
        }
        ?>
    </tbody>
    <tfoot>
        <tr><td colspan="6" style="text-align:right"><strong>Total Cash</strong></td><td colspan="3"><strong><?= number_format($totalCash, 2) ?></strong></td></tr>
    </tfoot>
</table>

<div style="margin-bottom:10px;">
    Show rows:
    <select id="rowsPerPage">
        <option>2</option>
        <option>5</option>
        <option selected>10</option>
        <option>25</option>
        <option>100</option>
        <option>1000</option>
        <option value="all">All</option>
    </select>
</div>

<div id="pagination" style="text-align: center; margin-top: 10px;"></div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
function sortTable(col) {
    const table = document.getElementById("entryTable");
    const rows = Array.from(table.rows).slice(1, -1);
    const asc = table.getAttribute("data-sort-dir") !== "asc";

    rows.sort((a, b) => {
        const aText = a.cells[col].innerText.trim();
        const bText = b.cells[col].innerText.trim();
        if (col === 6) {
            const aVal = parseFloat(aText.replace(/[^0-9.-]+/g,"")) || 0;
            const bVal = parseFloat(bText.replace(/[^0-9.-]+/g,"")) || 0;
            return asc ? aVal - bVal : bVal - aVal;
        }
        return asc ? aText.localeCompare(bText) : bText.localeCompare(aText);
    });

    for (const row of rows) table.tBodies[0].appendChild(row);
    table.setAttribute("data-sort-dir", asc ? "asc" : "desc");

    $(".sort-icon").text("");
    table.rows[0].cells[col].querySelector(".sort-icon").innerText = asc ? "▲" : "▼";
}

function applyFilters() {
    const guest = $("#filterGuest").val().toLowerCase();
    const mode = $("#filterMode").val().toLowerCase();
    const relation = $("#filterRelation").val().toLowerCase();
    const min = parseFloat($("#minCash").val()) || 0;
    const max = parseFloat($("#maxCash").val()) || Infinity;
    const start = $("#startDate").val();
    const end = $("#endDate").val();

    let summary = [];

    $("#entryTable tbody tr").each(function () {
        const tds = $(this).children("td");
        const g = tds.eq(1).text().toLowerCase();
        const m = tds.eq(7).text().toLowerCase();
        const r = tds.eq(3).text().toLowerCase();
        const c = parseFloat(tds.eq(6).text()) || 0;
        const d = tds.eq(8).text();

        let show = true;
        if (guest && !g.includes(guest)) show = false;
        if (mode && m !== mode) show = false;
        if (relation && r !== relation) show = false;
        if (c < min || c > max) show = false;
        if (start && d < start) show = false;
        if (end && d > end) show = false;

        $(this).toggle(show);
    });

    if (guest) summary.push(`Guest: "${guest}"`);
    if (mode) summary.push(`Mode: ${mode}`);
    if (relation) summary.push(`Relation: ${relation}`);
    if ($("#minCash").val()) summary.push(`Min: ${min}`);
    if ($("#maxCash").val()) summary.push(`Max: ${max}`);
    if (start) summary.push(`From: ${start}`);
    if (end) summary.push(`To: ${end}`);

    $("#filterSummary").html(summary.length ? "Active Filters: " + summary.join(", ") : "");
    updatePagination();
}

function clearFilters() {
    $("#filterGuest, #filterMode, #filterRelation, #minCash, #maxCash, #startDate, #endDate").val("");
    applyFilters();
}

function updatePagination() {
    var perPage = $('#rowsPerPage').val();
    var rows = $('#entryTable tbody tr:visible');
    var total = rows.length;

    if (perPage === 'all') {
        rows.show();
        $('#pagination').empty();
        return;
    }

    perPage = parseInt(perPage);
    var pages = Math.ceil(total / perPage);
    var current = 1;

    function showPage(page) {
        rows.hide();
        rows.slice((page - 1) * perPage, page * perPage).show();
        current = page;
        renderPagination();
    }

    function renderPagination() {
        var html = '';
        for (let i = 1; i <= pages; i++) {
            html += `<button onclick="showPage(${i})" ${i === current ? 'style="font-weight:bold;"' : ''}>${i}</button> `;
        }
        $('#pagination').html(html);
    }

    window.showPage = showPage;
    showPage(1);
}

$(document).ready(function () {
    $(".filters input, .filters select").on("input change", applyFilters);
    $("#rowsPerPage").on("change", updatePagination);
    applyFilters(); // Initial run
});
</script>
</body>
</html>
