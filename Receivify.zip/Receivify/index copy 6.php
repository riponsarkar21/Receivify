<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "receivify");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Receivify</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Receivify - Event Gift & Cash Tracker</h1>

    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <div style="text-align:right;">
            <a href="users.php">User Management</a>
        </div>
    <?php endif; ?>

    <form action="add_entry.php" method="POST">
        <label>Event Name:
            <input type="text" name="event" value="Ripon Akhi Wedding" required>
        </label><br>

        <label>Guest Name:
            <input type="text" name="guest" required>
        </label><br>

        <label>Mobile Number:
            <input type="tel" name="mobile" pattern="[0-9]{11}" placeholder="e.g. 017xxxxxxxx" required>
        </label><br>

        <label>Relation:
            <input type="text" name="relation" placeholder="e.g. Cousin, Friend, Uncle">
        </label><br>

        <label>Address:
            <input type="text" name="address">
        </label><br>

        <label>Gift Description:
            <input type="text" name="gift">
        </label><br>

        <label>Cash Amount:
            <input type="number" name="cash" min="0">
        </label><br>

        <label>Mode of Giving:
            <select name="mode">
                <option value="In-person">In-person</option>
                <option value="Online">Online</option>
                <option value="Proxy">Proxy</option>
            </select>
        </label><br>

        <button type="submit">Add Entry</button>
    </form>

    <h2>Gift/Cash Entries</h2>

    <input type="text" id="searchInput" placeholder="Search entries..." style="width:100%; padding:8px; margin:10px 0;">

    <div style="margin-bottom: 10px;">
        <a href="export_excel.php" target="_blank"><button>Export to Excel</button></a>
        <a href="export_pdf.php" target="_blank"><button>Export to PDF</button></a>
    </div>

    <table border="1" id="entryTable">
        <tr>
            <th>Event</th>
            <th>Guest</th>
            <th>Mobile</th>
            <th>Relation</th>
            <th>Address</th>
            <th>Gift</th>
            <th>Cash</th>
            <th>Mode</th>
            <th>Time</th>
        </tr>
        <?php
        $result = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='event'>{$row['event']}</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='guest'>{$row['guest']}</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='mobile'>{$row['mobile']}</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='relation'>{$row['relation']}</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='address'>{$row['address']}</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='gift'>{$row['gift']}</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='cash'>{$row['cash']}</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='mode'>{$row['mode']}</td>";
            echo "<td>{$row['created_at']}</td>";
            echo "</tr>";
        }
        ?>
    </table>

    <script>
        // Inline editing
        $(document).ready(function(){
            $('.editable').blur(function(){
                var id = $(this).data('id');
                var column = $(this).data('column');
                var value = $(this).text();

                $.post('update_entry.php', {
                    id: id,
                    column: column,
                    value: value
                }, function(response){
                    console.log(response);
                });
            });

            // Search
            $("#searchInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#entryTable tr").each(function(index) {
                    if (index === 0) return; // Skip header row
                    var rowText = $(this).text().toLowerCase();
                    $(this).toggle(rowText.indexOf(value) > -1);
                });
            });

        });
    </script>
</body>
</html>
