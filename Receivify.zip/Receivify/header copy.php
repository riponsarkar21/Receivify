<?php
// header.php
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Receivify</title>
    <link rel="stylesheet" href="style.css">
    <style>
    </style>
</head>
<body>
<header>
    <h1>Receivify - Event Gift & Cash Tracker</h1>
</header>
