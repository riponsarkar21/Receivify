<?php
session_start();
require_once 'db.php';
require_once 'auth.php';

// Totals
$totalGuests = $mysqli->query("SELECT COUNT(*) AS count FROM entries")->fetch_assoc()['count'];
$totalGifts  = $mysqli->query("SELECT COUNT(*) AS count FROM entries WHERE gift IS NOT NULL AND gift != ''")->fetch_assoc()['count'];
$totalCash   = $mysqli->query("SELECT SUM(cash) AS total FROM entries")->fetch_assoc()['total'] ?? 0;

// User-wise collection
$userSummary = $mysqli->query("
    SELECT 
        u.username,
        COUNT(e.id) AS guest_count,
        SUM(e.cash) AS total_cash
    FROM users u
    LEFT JOIN entries e ON e.created_by = u.id
    GROUP BY u.username
    ORDER BY guest_count DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Receivify Dashboard</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style_index.css">
</head>
<body>

<?php include 'includes/header.php'; ?>

<h3>Dashboard</h3>

<div class="card-container">
    <div class="card">
        <h2>Total Guests</h2>
        <p><?= $totalGuests ?></p>
    </div>
    <div class="card">
        <h2>Gifts Received</h2>
        <p><?= $totalGifts ?></p>
    </div>
    <div class="card">
        <h2>Total Cash Received</h2>
        <p>৳ <?= number_format($totalCash) ?></p>
    </div>
</div>

<h2>User-wise Collection Summary</h2>
<table>
    <thead>
        <tr>
            <th>User</th>
            <th>Total Guests Handled</th>
            <th>Total Cash Received</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $userSummary->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= $row['guest_count'] ?></td>
            <td>৳ <?= number_format($row['total_cash'] ?? 0) ?></td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<?php include 'includes/footer.php'; ?>
</body>
</html>
