<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$created_by = $_SESSION['user_id'];  // user ID from session
$event      = $_POST['event'];
$guest      = $_POST['guest'];
$mobile     = $_POST['mobile'];
$relation   = $_POST['relation'];
$address    = $_POST['address'];
$gift       = $_POST['gift'];
$cash       = $_POST['cash'];
$mode       = $_POST['mode'];

$stmt = $mysqli->prepare("INSERT INTO entries (event, guest, mobile, relation, address, gift, cash, mode, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssdsi", $event, $guest, $mobile, $relation, $address, $gift, $cash, $mode, $created_by);
$stmt->execute();

header("Location: index.php");
exit;

?>
