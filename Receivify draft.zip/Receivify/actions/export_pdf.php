<?php
// require_once('tcpdf/tcpdf.php');
require_once(__DIR__ . '/../tcpdf/tcpdf.php');
require_once '../db.php';

$pdf = new TCPDF();
$pdf->AddPage();
$pdf->SetFont('helvetica', '', 12);

$html = '<h2>Receivify - Gift/Cash Entries</h2><table border="1" cellpadding="4">
<tr><th>Event</th><th>Guest</th><th>Gift</th><th>Cash</th><th>Mode</th><th>Time</th></tr>';

$result = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
while ($row = $result->fetch_assoc()) {
    $html .= "<tr>
        <td>{$row['event']}</td>
        <td>{$row['guest']}</td>
        <td>{$row['gift']}</td>
        <td>{$row['cash']}</td>
        <td>{$row['mode']}</td>
        <td>{$row['created_at']}</td>
    </tr>";
}
$html .= "</table>";

$pdf->writeHTML($html, true, false, true, false, '');
$pdf->Output('receivify_export.pdf', 'D');
?>
