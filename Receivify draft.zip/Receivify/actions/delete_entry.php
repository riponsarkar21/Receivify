<?php
session_start();
require_once 'auth.php';
require_once 'db.php';

if ($_SESSION['role'] !== 'admin') {
    http_response_code(403);
    exit("Only admin can delete.");
}

$id = $_POST['id'];

// Fetch original data
$entry = $mysqli->query("SELECT * FROM entries WHERE id = $id")->fetch_assoc();

// Insert into deletion_log
$stmt = $mysqli->prepare("INSERT INTO deletion_log 
(entry_id, deleted_by, deleted_at, event, guest, mobile, relation, address, gift, cash, mode, created_at)
VALUES (?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param(
    "isssssssdss",
    $entry['id'],
    $_SESSION['username'],
    $entry['event'],
    $entry['guest'],
    $entry['mobile'],
    $entry['relation'],
    $entry['address'],
    $entry['gift'],
    $entry['cash'],
    $entry['mode'],
    $entry['created_at']
);

$stmt->execute();

// Delete from entries
$mysqli->query("DELETE FROM entries WHERE id = $id");

echo "Deleted";
?>
