<?php
session_start();
require_once 'auth.php';
require_once 'db.php';

$id = $_POST['id'];

$result = $mysqli->prepare("SELECT created_by FROM entries WHERE id = ?");
$result->bind_param("i", $id);
$result->execute();
$result->bind_result($owner);
$result->fetch();
$result->close();

if ($_SESSION['role'] !== 'admin' && $_SESSION['username'] !== $owner) {
    http_response_code(403);
    exit("Unauthorized");
}

$stmt = $mysqli->prepare("UPDATE entries SET is_canceled = 1, canceled_by = ?, canceled_at = NOW() WHERE id = ?");
$stmt->bind_param("si", $_SESSION['username'], $id);
$stmt->execute();

echo "Canceled";
?>
