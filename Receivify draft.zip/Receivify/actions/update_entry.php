<?php
// update_entry.php

// Return JSON response
header('Content-Type: application/json');
session_start();

// Include database connection
require_once(__DIR__ . '/../db.php');

// Enable full error reporting (for debugging; disable in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Initialize JSON response
$response = ['success' => false, 'message' => 'Unknown error occurred'];

// Ensure POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Log raw POST data (for debugging)
    error_log('POST DATA: ' . print_r($_POST, true));

    // Collect & sanitize input
    $id       = $_POST['id'] ?? null;
    $guest    = trim($_POST['guest'] ?? '');
    $mobile   = trim($_POST['mobile'] ?? '');
    $relation = trim($_POST['relation'] ?? '');
    $address  = trim($_POST['address'] ?? '');
    $gift     = trim($_POST['gift'] ?? '');
    $cash     = floatval($_POST['cash'] ?? 0);
    $mode     = trim($_POST['mode'] ?? '');
    $user_id  = $_SESSION['user_id'] ?? 0;

    // Basic validation
    if (!$id || $guest === '' || $mobile === '') {
        $response['message'] = 'Missing required fields: ID, Guest or Mobile.';
        echo json_encode($response);
        exit;
    }

    // Prepare update query
    $stmt = $mysqli->prepare("
        UPDATE collections 
        SET guest = ?, mobile = ?, relation = ?, address = ?, gift = ?, cash = ?, mode = ?, updated_by = ?, updated_at = NOW()
        WHERE id = ?
    ");

    if (!$stmt) {
        $response['message'] = 'Prepare failed: ' . $mysqli->error;
        echo json_encode($response);
        exit;
    }

    $stmt->bind_param("ssssssdii", $guest, $mobile, $relation, $address, $gift, $cash, $mode, $user_id, $id);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Entry updated successfully.';
    } else {
        $response['message'] = 'Execute failed: ' . $stmt->error;
    }

    $stmt->close();
} else {
    $response['message'] = 'Invalid request method.';
}

// Return final JSON
echo json_encode($response);
exit;
