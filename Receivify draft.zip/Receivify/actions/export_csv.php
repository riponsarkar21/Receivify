<?php
// actions/export_csv.php
require_once '../db.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename=collection.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'Guest', 'Mobile', 'Relation', 'Address', 'Gift', 'Cash', 'Mode', 'Created At', 'Status']);

$query = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
while ($row = $query->fetch_assoc()) {
    fputcsv($output, [
        $row['id'], $row['guest'], $row['mobile'], $row['relation'],
        $row['address'], $row['gift'], $row['cash'], $row['mode'],
        $row['created_at'], $row['status']
    ]);
}
fclose($output);
exit;
