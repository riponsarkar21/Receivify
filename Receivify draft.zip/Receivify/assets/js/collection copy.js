$(function () {
    // Modal
    $("#addCollectionBtn").click(() => $("#entryModal").fadeIn());
    $("#closeModal").click(() => $("#entryModal").fadeOut());
    $("#entryModal").click(e => { if (e.target.id === "entryModal") $(this).fadeOut(); });

    // Inline editing
    $(".editable").on("blur", function () {
        let row = $(this).closest('tr');
        let id = row.data("id");
        let column = $(this).data("column");
        let value = $(this).text();
        $.post("update_entry.php", { id, column, value }, res => console.log(res));
    });

    // Cancel
    $(".cancelBtn").click(function () {
        if (confirm("Cancel this entry?")) {
            let id = $(this).closest("tr").data("id");
            $.post("cancel_entry.php", { id }, () => location.reload());
        }
    });

    // Delete
    $(".deleteBtn").click(function () {
        if (confirm("Delete this entry permanently?")) {
            let id = $(this).closest("tr").data("id");
            $.post("delete_entry.php", { id }, () => location.reload());
        }
    });

    // View History
    $(".viewHistoryBtn").click(function () {
        let id = $(this).closest("tr").data("id");
        $.get("history.php", { id }, function (data) {
            $("#historyContent").html(data);
            $("#historyModal").fadeIn();
        });
    });

    $("#closeHistoryModal").click(() => $("#historyModal").fadeOut());

    // Search
    $("#searchInput").on("input", function () {
        let val = $(this).val().toLowerCase();
        $("#entryTable tbody tr").each(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(val) > -1);
        });
    });

    // Filters
    function applyFilters() {
        let guest = $("#filterGuest").val().toLowerCase();
        let mode = $("#filterMode").val().toLowerCase();
        let relation = $("#filterRelation").val().toLowerCase();
        let min = parseFloat($("#minCash").val());
        let max = parseFloat($("#maxCash").val());

        $("#entryTable tbody tr").each(function () {
            let row = $(this);
            let g = row.find("[data-column='guest']").text().toLowerCase();
            let m = row.find("[data-column='mode']").text().toLowerCase();
            let r = row.find("[data-column='relation']").text().toLowerCase();
            let c = parseFloat(row.find("[data-column='cash']").text()) || 0;
            let show = (!guest || g.includes(guest)) && (!mode || m === mode) && (!relation || r === relation) &&
                (isNaN(min) || c >= min) && (isNaN(max) || c <= max);
            row.toggle(show);
        });
    }

    $("#filterGuest, #filterMode, #filterRelation, #minCash, #maxCash").on("input change", applyFilters);
});







$(document).ready(function () {
    // Open Edit Modal
    $('.editBtn').click(function () {
        const row = $(this).closest('tr');
        $('#editId').val(row.data('id'));
        $('#editGuest').val(row.find('td').eq(1).text());
        $('#editMobile').val(row.find('td').eq(2).text());
        $('#editRelation').val(row.find('td').eq(3).text());
        $('#editAddress').val(row.find('td').eq(4).text());
        $('#editGift').val(row.find('td').eq(5).text());
        $('#editCash').val(row.find('td').eq(6).text());
        $('#editMode').val(row.find('td').eq(7).text());

        $('#editModal').show();
    });

    // Close Edit Modal
    $('#closeEditModal').click(function () {
        $('#editModal').hide();
    });

    // Submit Edit
    $('#editForm').submit(function (e) {
        e.preventDefault();
        $.post('actions/update_entry.php', $(this).serialize(), function (response) {
            alert(response.message);
            if (response.success) location.reload();
        }, 'json');
    });
});

