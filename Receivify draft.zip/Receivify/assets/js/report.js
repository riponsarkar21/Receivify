$(document).ready(function () {
    const $table = $("#entryTable");
    const $tbody = $table.find("tbody");
    const $rows = $tbody.find("tr");
    const $pagination = $("#pagination");
    const $rowsPerPage = $("#rowsPerPage");
    const $filterGuest = $("#filterGuest");
    const $filterMode = $("#filterMode");
    const $filterRelation = $("#filterRelation");
    const $minCash = $("#minCash");
    const $maxCash = $("#maxCash");
    const $startDate = $("#startDate");
    const $endDate = $("#endDate");
    const $filterSummary = $(".filter-summary");

    let currentPage = 1;

    function applyFiltersAndRender() {
        const guestVal = $filterGuest.val().toLowerCase();
        const modeVal = $filterMode.val();
        const relationVal = $filterRelation.val();
        const minCash = parseFloat($minCash.val()) || -Infinity;
        const maxCash = parseFloat($maxCash.val()) || Infinity;
        const startDate = new Date($startDate.val());
        const endDate = new Date($endDate.val());

        let filtered = $rows.filter(function () {
            const $cells = $(this).find("td");
            const guest = $cells.eq(1).text().toLowerCase();
            const mode = $cells.eq(7).text();
            const relation = $cells.eq(3).text();
            const cash = parseFloat($cells.eq(6).text()) || 0;
            const dateStr = $cells.eq(8).text();
            const entryDate = new Date(dateStr);

            return (
                (!guestVal || guest.includes(guestVal)) &&
                (!modeVal || mode === modeVal) &&
                (!relationVal || relation === relationVal) &&
                cash >= minCash &&
                cash <= maxCash &&
                (!isNaN(startDate.getTime()) ? entryDate >= startDate : true) &&
                (!isNaN(endDate.getTime()) ? entryDate <= endDate : true)
            );
        });

        renderTable(filtered);
        updateFilterSummary(filtered.length);
    }

    function updateFilterSummary(count) {
        let summary = `${count} rows matched`;
        let details = [];

        if ($filterGuest.val()) details.push(`Guest: "${$filterGuest.val()}"`);
        if ($filterMode.val()) details.push(`Mode: ${$filterMode.val()}`);
        if ($filterRelation.val()) details.push(`Relation: ${$filterRelation.val()}`);
        if ($minCash.val()) details.push(`Min Cash: ${$minCash.val()}`);
        if ($maxCash.val()) details.push(`Max Cash: ${$maxCash.val()}`);
        if ($startDate.val()) details.push(`From: ${$startDate.val()}`);
        if ($endDate.val()) details.push(`To: ${$endDate.val()}`);

        if (details.length) summary += " (" + details.join(", ") + ")";
        $filterSummary.text(summary);
    }

    function renderTable(filteredRows) {
        const perPage = $rowsPerPage.val() === "all" ? filteredRows.length : parseInt($rowsPerPage.val());
        const totalPages = Math.ceil(filteredRows.length / perPage);
        currentPage = Math.min(currentPage, totalPages || 1);

        $tbody.empty();
        const start = (currentPage - 1) * perPage;
        const end = start + perPage;
        filteredRows.slice(start, end).appendTo($tbody);

        updatePagination(filteredRows.length, perPage);
        updateTotalCash();
    }

    function updatePagination(total, perPage) {
        $pagination.empty();
        if (perPage === total || perPage === 0 || perPage === "all") return;

        const totalPages = Math.ceil(total / perPage);
        for (let i = 1; i <= totalPages; i++) {
            const $btn = $("<button>").text(i);
            if (i === currentPage) $btn.attr("disabled", true);
            $btn.click(() => {
                currentPage = i;
                applyFiltersAndRender();
            });
            $pagination.append($btn);
        }
    }

    function updateTotalCash() {
        let total = 0;
        $tbody.find("tr").each(function () {
            const cash = parseFloat($(this).find(".cash").text()) || 0;
            total += cash;
        });
        $("#cashTotal").text(total.toFixed(2));
    }

    function clearFilters() {
        $filterGuest.val('');
        $filterMode.val('');
        $filterRelation.val('');
        $minCash.val('');
        $maxCash.val('');
        $startDate.val('');
        $endDate.val('');
        applyFiltersAndRender();
    }

    function sortTable(columnIndex) {
        const $th = $table.find("th").eq(columnIndex);
        const isAsc = !$th.hasClass("asc");
        $table.find("th").removeClass("asc desc");
        $th.addClass(isAsc ? "asc" : "desc");

        const sorted = $tbody.find("tr").get().sort((a, b) => {
            const A = $(a).children("td").eq(columnIndex).text();
            const B = $(b).children("td").eq(columnIndex).text();

            const isNumeric = !isNaN(parseFloat(A)) && !isNaN(parseFloat(B));
            if (isNumeric) {
                return isAsc ? A - B : B - A;
            } else {
                return isAsc ? A.localeCompare(B) : B.localeCompare(A);
            }
        });

        $tbody.html(sorted);
        updateTotalCash();
    }

    function exportFiltered(format) {
        const rows = [];
        $tbody.find("tr").each(function () {
            const row = [];
            $(this).find("td").each(function () {
                row.push($(this).text());
            });
            rows.push(row);
        });

        // Send rows to server for export (optional - backend required)
        alert(`Exporting ${rows.length} filtered rows as ${format.toUpperCase()}`);
    }

    // Event bindings
    $(".filters input, .filters select").on("input change", applyFiltersAndRender);
    $("#clearFilters").click(clearFilters);
    $rowsPerPage.change(() => {
        currentPage = 1;
        applyFiltersAndRender();
    });

    // Enable sortable columns
    $table.find("th.sortable").each(function (index) {
        $(this).click(() => sortTable(index));
    });

    // Initial render
    applyFiltersAndRender();
});
