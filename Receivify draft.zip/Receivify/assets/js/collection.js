$(function () {
    // ------------------------
    // ADD ENTRY MODAL
    // ------------------------
    $("#addCollectionBtn").click(() => $("#entryModal").fadeIn());
    $("#closeModal").click(() => $("#entryModal").fadeOut());
    $("#entryModal").click(function (e) {
        if (e.target.id === "entryModal") $(this).fadeOut();
    });

    // ------------------------
    // EDIT ENTRY MODAL
    // ------------------------
    $(".editBtn").click(function () {
        const row = $(this).closest("tr");

        $('#editId').val(row.data('id'));
        $('#editGuest').val(row.find('td').eq(1).text());
        $('#editMobile').val(row.find('td').eq(2).text());
        $('#editRelation').val(row.find('td').eq(3).text());
        $('#editAddress').val(row.find('td').eq(4).text());
        $('#editGift').val(row.find('td').eq(5).text());
        $('#editCash').val(row.find('td').eq(6).text());
        $('#editMode').val(row.find('td').eq(7).text());

        $('#editModal').fadeIn();
    });

    $("#closeEditModal").click(() => $("#editModal").fadeOut());
    $("#editModal").click(function (e) {
        if (e.target.id === "editModal") $(this).fadeOut();
    });

    // ------------------------
    // SUBMIT EDIT FORM (AJAX)
    // ------------------------
    $("#editForm").submit(function (e) {
        e.preventDefault();
        $.ajax({
            url: "actions/update_entry.php",
            type: "POST",
            data: $(this).serialize(),
            dataType: "json",
            success: function (response) {
                if (response.success) {
                    alert(response.message);
                    location.reload();
                } else {
                    alert("Error: " + response.message);
                }
            },
            error: function (xhr, status, error) {
                console.error("AJAX raw response:\n", xhr.responseText);
                alert("AJAX Error!\n\n" + error + "\n\nRaw Server Response:\n" + xhr.responseText);
            }
        });
    });

    // ------------------------
    // CANCEL ENTRY
    // ------------------------
    $(".cancelBtn").click(function () {
        if (confirm("Cancel this entry?")) {
            let id = $(this).closest("tr").data("id");
            $.post("cancel_entry.php", { id }, () => location.reload());
        }
    });

    // ------------------------
    // DELETE ENTRY
    // ------------------------
    $(".deleteBtn").click(function () {
        if (confirm("Delete this entry permanently?")) {
            let id = $(this).closest("tr").data("id");
            $.post("delete_entry.php", { id }, () => location.reload());
        }
    });

    // ------------------------
    // VIEW HISTORY
    // ------------------------
    $(".viewHistoryBtn").click(function () {
        let id = $(this).closest("tr").data("id");
        $.get("history.php", { id }, function (data) {
            $("#historyContent").html(data);
            $("#historyModal").fadeIn();
        });
    });

    $("#closeHistoryModal").click(() => $("#historyModal").fadeOut());
    $("#historyModal").click(function (e) {
        if (e.target.id === "historyModal") $(this).fadeOut();
    });

    // ------------------------
    // SEARCH
    // ------------------------
    $("#searchInput").on("input", function () {
        let val = $(this).val().toLowerCase();
        $("#entryTable tbody tr").each(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(val) > -1);
        });
    });

    // ------------------------
    // ADVANCED FILTERS
    // ------------------------
    function applyFilters() {
        let guest = $("#filterGuest").val().toLowerCase();
        let mode = $("#filterMode").val().toLowerCase();
        let relation = $("#filterRelation").val().toLowerCase();
        let min = parseFloat($("#minCash").val());
        let max = parseFloat($("#maxCash").val());

        $("#entryTable tbody tr").each(function () {
            let row = $(this);
            let g = row.find("td").eq(1).text().toLowerCase();
            let m = row.find("td").eq(7).text().toLowerCase();
            let r = row.find("td").eq(3).text().toLowerCase();
            let c = parseFloat(row.find("td").eq(6).text()) || 0;

            let show =
                (!guest || g.includes(guest)) &&
                (!mode || m === mode) &&
                (!relation || r === relation) &&
                (isNaN(min) || c >= min) &&
                (isNaN(max) || c <= max);

            row.toggle(show);
        });
    }

    $("#filterGuest, #filterMode, #filterRelation, #minCash, #maxCash").on("input change", applyFilters);
});
