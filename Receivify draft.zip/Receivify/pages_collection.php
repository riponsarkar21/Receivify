<?php
// pages_collection.php 

require_once 'auth.php';
require_once 'db.php';

$isAdmin = $_SESSION['role'] === 'admin';
$currentUser = $_SESSION['username'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Receivify - Collection</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style_collection.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<?php include 'includes/header.php'; ?>

<h3>Collection</h3>

<button type="button" id="addCollectionBtn">Add Collection</button>

<div id="entryModal">
    <div class="modal-content">
        <span id="closeModal">&times;</span>
        <h2>Add Entry</h2>
        <form action="actions/add_entry.php" method="POST">
            <input type="hidden" name="username" value="<?= $currentUser ?>">
            <label>Event Name:
                <input type="text" name="event" value="Ripon Akhi Wedding" required>
            </label>
            <label>Guest Name:
                <input type="text" name="guest" required>
            </label>
            <label>Mobile Number:
                <input type="tel" name="mobile" pattern="[0-9]{11}" required>
            </label>
            <label>Relation:
                <input type="text" name="relation">
            </label>
            <label>Address:
                <input type="text" name="address">
            </label>
            <label>Gift:
                <input type="text" name="gift">
            </label>
            <label>Cash:
                <input type="number" name="cash" min="0">
            </label>
            <label>Mode:
                <select name="mode">
                    <option value="In-person">In-person</option>
                    <option value="Online">Online</option>
                    <option value="Proxy">Proxy</option>
                </select>
            </label>
            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<div id="editModal" class="modal-overlay" style="display: none;">
    <div class="modal-content">
        <span id="closeEditModal">&times;</span>
        <h3>Edit Entry</h3>
        <form id="editForm">
            <input type="hidden" name="editId" id="editId">
            <label>Guest: <input type="text" name="guest" id="editGuest" required></label>
            <label>Mobile: <input type="tel" name="mobile" id="editMobile" required></label>
            <label>Relation: <input type="text" name="relation" id="editRelation"></label>
            <label>Address: <input type="text" name="address" id="editAddress"></label>
            <label>Gift: <input type="text" name="gift" id="editGift"></label>
            <label>Cash: <input type="number" name="cash" id="editCash" min="0"></label>
            <label>Mode:
                <select name="mode" id="editMode">
                    <option value="In-person">In-person</option>
                    <option value="Online">Online</option>
                    <option value="Proxy">Proxy</option>
                </select>
            </label>
            <button type="submit">Save</button>
        </form>
    </div>
</div>

<input type="text" id="searchInput" placeholder="Search entries...">

<div id="filters">
    <input type="text" id="filterGuest" placeholder="Filter by guest...">
    <select id="filterMode">
        <option value="">All Modes</option>
        <option value="In-person">In-person</option>
        <option value="Online">Online</option>
        <option value="Proxy">Proxy</option>
    </select>
    <select id="filterRelation">
        <option value="">All Relations</option>
        <?php
        $relations = $mysqli->query("SELECT DISTINCT relation FROM entries WHERE relation != '' ORDER BY relation ASC");
        while ($rel = $relations->fetch_assoc()) {
            echo "<option value='{$rel['relation']}'>{$rel['relation']}</option>";
        }
        ?>
    </select>
    <input type="number" id="minCash" placeholder="Min cash">
    <input type="number" id="maxCash" placeholder="Max cash">
</div>

<div class="export-buttons">
    <a href="actions/export_excel.php" target="_blank"><button>Export to Excel</button></a>
    <a href="actions/export_pdf.php" target="_blank"><button>Export to PDF</button></a>
    <a href="actions/export_csv.php" target="_blank"><button>Export to CSV</button></a>
</div>

<table id="entryTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Guest</th>
            <th>Mobile</th>
            <th>Relation</th>
            <th>Address</th>
            <th>Gift</th>
            <th>Cash</th>
            <th>Mode</th>
            <th>Time</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $entries = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
        while ($row = $entries->fetch_assoc()) {
            $editable = $isAdmin || $row['created_by'] === $currentUser;
            echo "<tr data-id='{$row['id']}'>";
            echo "<td>{$row['id']}</td>";
            echo "<td>{$row['guest']}</td>";
            echo "<td>{$row['mobile']}</td>";
            echo "<td>{$row['relation']}</td>";
            echo "<td>{$row['address']}</td>";
            echo "<td>{$row['gift']}</td>";
            echo "<td>{$row['cash']}</td>";
            echo "<td>{$row['mode']}</td>";
            echo "<td>{$row['created_at']}</td>";
            echo "<td>" . ($row['status'] ?? 'Active') . "</td>";

            echo "<td>";
            echo "<button class='editBtn'>Edit</button> ";
            echo "<button class='cancelBtn'>Cancel</button> ";
            echo "<button class='pdfBtn'>PDF</button> ";
            echo "<button onclick='window.print()'>Print</button> ";
            echo "<button class='viewHistoryBtn'>Details</button> ";
            if ($isAdmin) echo "<button class='deleteBtn'>Delete</button>";
            echo "</td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>

<!-- History Modal -->
<div id="historyModal" style="display:none;" class="modal-overlay">
    <div class="modal-content">
        <span id="closeHistoryModal">&times;</span>
        <h3>Entry History</h3>
        <div id="historyContent"></div>
    </div>
</div>

<script src="assets/js/collection.js"></script>

<?php include 'includes/footer.php'; ?>
</body>
</html>
