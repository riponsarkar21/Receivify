<?php
// db.php

$host = 'localhost';         // Change if different
$db   = 'receivify';         // Your database name
$user = 'root';              // DB username (e.g., root)
$pass = '';                  // DB password
$charset = 'utf8mb4';

// Create mysqli connection
$mysqli = new mysqli($host, $user, $pass, $db);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Optional: Set charset
$mysqli->set_charset($charset);
?>
