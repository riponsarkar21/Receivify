<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Access Denied</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            text-align: center;
            padding: 50px;
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
        }
        .access-denied {
            background-color: #fff;
            padding: 40px;
            border: 1px solid #ccc;
            display: inline-block;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .access-denied h1 {
            color: #e74c3c;
        }
        .access-denied a {
            text-decoration: none;
            color: #3498db;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="access-denied">
        <h1>Access Denied</h1>
        <p>You do not have permission to access this page.</p>
        <p><a href="index.php">Return to Home</a></p>
    </div>
</body>
</html>
