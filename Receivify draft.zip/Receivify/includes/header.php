<?php
// header.php

require_once 'auth.php';
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Receivify</title>
    <link rel="stylesheet" href="assets\css\style.css">
</head>
<body>
<header>
    <h1>Receivify - Event Gift & Cash Tracker</h1>
</header>

<div class="header">
        <a href="index.php">Home</a>
        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <div style="text-align:right;">
            <a href="pages_users.php">User Management</a>
            <a href="pages_report.php">Report</a>

        </div>
    <?php endif ; ?>
        <a href="pages_collection.php">Collection</a>
    


    <?php if (isset($_SESSION['username'])): ?>
        <div class="user-info">
            Logged in as <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            | <a href="logout.php">Logout</a>
        </div>
    <?php endif; ?>

</div>
