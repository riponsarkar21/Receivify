<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "receivify");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

$requireAdmin = true;
require_once 'auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report - Receivify</title>
    <link rel="stylesheet" href="assets\css\style_report.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<?php include 'includes\header.php'; ?>

<h1 class="page-title">Report</h1>

<div class="controls">
    <div class="filters">
        <input type="text" id="filterGuest" placeholder="Filter by guest">
        <select id="filterMode">
            <option value="">All Modes</option>
            <option value="In-person">In-person</option>
            <option value="Online">Online</option>
            <option value="Proxy">Proxy</option>
        </select>
        <select id="filterRelation">
            <option value="">All Relations</option>
            <?php
            $relations = $mysqli->query("SELECT DISTINCT relation FROM entries WHERE relation != '' ORDER BY relation ASC");
            while ($rel = $relations->fetch_assoc()) {
                $safeRelation = htmlspecialchars($rel['relation']);
                echo "<option value='{$safeRelation}'>{$safeRelation}</option>";
            }
            ?>
        </select>
        <input type="number" id="minCash" placeholder="Min cash">
        <input type="number" id="maxCash" placeholder="Max cash">
        <input type="date" id="startDate">
        <input type="date" id="endDate">
        <button id="clearFilters" class="clear-filters-btn">Clear Filters</button>
    </div>

    <div class="export-buttons">
        <button onclick="exportFiltered('excel')">Export Excel</button>
        <button onclick="exportFiltered('csv')">Export CSV</button>
        <button onclick="exportFiltered('pdf')">Export PDF</button>
        <button onclick="window.print()">Print</button>
    </div>
</div>

<div class="filter-summary"></div>

<div id="rowsControl">
    Show rows:
    <select id="rowsPerPage">
        <option>2</option>
        <option>5</option>
        <option selected>10</option>
        <option>25</option>
        <option>100</option>
        <option>1000</option>
        <option value="all">All</option>
    </select>
</div>

<table id="entryTable">
    <thead>
        <tr>
            <th class="sortable">Event</th>
            <th class="sortable">Guest</th>
            <th>Mobile</th>
            <th class="sortable">Relation</th>
            <th>Address</th>
            <th>Gift</th>
            <th class="sortable">Cash</th>
            <th class="sortable">Mode</th>
            <th class="sortable">Date</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $entries = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
        $totalCash = 0;
        while ($row = $entries->fetch_assoc()) {
            $totalCash += $row['cash'];
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['event']) . "</td>";
            echo "<td>" . htmlspecialchars($row['guest']) . "</td>";
            echo "<td>" . htmlspecialchars($row['mobile']) . "</td>";
            echo "<td>" . htmlspecialchars($row['relation']) . "</td>";
            echo "<td>" . htmlspecialchars($row['address']) . "</td>";
            echo "<td>" . htmlspecialchars($row['gift']) . "</td>";
            echo "<td class='cash'>" . htmlspecialchars($row['cash']) . "</td>";
            echo "<td>" . htmlspecialchars($row['mode']) . "</td>";
            echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
            echo "</tr>";
        }
        ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="6" class="right-align"><strong>Total Cash:</strong></td>
            <td colspan="3"><strong id="cashTotal"><?php echo number_format($totalCash, 2); ?></strong></td>
        </tr>
    </tfoot>
</table>

<div id="pagination"></div>

<script src="assets\js\report.js"></script>

<?php include 'includes\footer.php'; ?>
</body>
</html>
