<?php
session_start();
$mysqli = new mysqli("localhost", "root", "", "receivify");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Collect form data
$event    = $_POST['event'];
$guest    = $_POST['guest'];
$mobile   = $_POST['mobile'];
$relation = $_POST['relation'];
$address  = $_POST['address'];
$gift     = $_POST['gift'];
$cash     = $_POST['cash'] !== '' ? $_POST['cash'] : 0;
$mode     = $_POST['mode'];

// Insert entry
$stmt = $mysqli->prepare("INSERT INTO entries (event, guest, mobile, relation, address, gift, cash, mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssds", $event, $guest, $mobile, $relation, $address, $gift, $cash, $mode);
$stmt->execute();
$stmt->close();
$mysqli->close();

header("Location: index.php");
exit();
?>
