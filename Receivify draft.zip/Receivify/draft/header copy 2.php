<?php
// header.php
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Receivify</title>
    <link rel="stylesheet" href="style.css">
    <style>
    </style>
</head>
<body>
<header>
    <h1>Receivify - Event Gift & Cash Tracker</h1>
</header>


<!-- header.php -->
<div class="header">
    <!-- <h1>Receivify</h1> -->
    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <div style="text-align:right;">
            <a href="users.php">User Management</a>
            <a href="users.php">User Management</a>
        </div>
            <a href="report.php">Report</a>

    <?php endif; ?>
            <a href="report.php">Report</a>


    <?php if (isset($_SESSION['username'])): ?>
        <div class="user-info">
            Logged in as <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            | <a href="logout.php">Logout</a>
        </div>
    <?php endif; ?>
</div>
