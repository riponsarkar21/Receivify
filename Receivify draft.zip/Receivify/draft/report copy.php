<?php
$mysqli = new mysqli("localhost", "root", "", "receivify");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Receivify Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
        }

        h2 {
            text-align: center;
        }

        .no-print {
            margin-bottom: 15px;
        }

        .no-print button {
            padding: 8px 12px;
            cursor: pointer;
        }

        #filters {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }

        #filters input, #filters select {
            padding: 8px;
            flex: 1;
            min-width: 150px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 8px;
        }

        th {
            background-color: #f0f0f0;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        td[contenteditable="true"] {
            background-color: #fffceb;
        }

        @media print {
            .no-print {
                display: none !important;
            }

            table {
                font-size: 12px;
            }

            h2 {
                text-align: center;
            }
        }
    </style>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<h2>Gift/Cash Entries</h2>

<!-- Print & Export Buttons -->
<div class="no-print" style="display: flex; gap: 10px;">
    <button onclick="window.print()">🖨️ Print</button>
    <a href="export_excel.php" target="_blank"><button>📊 Export to Excel</button></a>
    <a href="export_pdf.php" target="_blank"><button>📄 Export to PDF</button></a>
</div>

<!-- Filters -->
<div class="no-print" id="filters">
    <input type="text" id="filterGuest" placeholder="Filter by guest name...">
    
    <select id="filterMode">
        <option value="">All Modes</option>
        <option value="In-person">In-person</option>
        <option value="Online">Online</option>
        <option value="Proxy">Proxy</option>
    </select>

    <select id="filterRelation">
        <option value="">All Relations</option>
        <?php
        $relations = $mysqli->query("SELECT DISTINCT relation FROM entries WHERE relation IS NOT NULL AND relation != '' ORDER BY relation ASC");
        while ($rel = $relations->fetch_assoc()) {
            $relationVal = htmlspecialchars($rel['relation']);
            echo "<option value=\"{$relationVal}\">{$relationVal}</option>";
        }
        ?>
    </select>

    <input type="number" id="minCash" placeholder="Min cash">
    <input type="number" id="maxCash" placeholder="Max cash">
</div>

<!-- Data Table -->
<table border="1" id="entryTable">
    <tr>
        <th>Event</th>
        <th>Guest</th>
        <th>Mobile</th>
        <th>Relation</th>
        <th>Address</th>
        <th>Gift</th>
        <th>Cash</th>
        <th>Mode</th>
        <th>Time</th>
    </tr>
    <?php
    $result = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='event'>{$row['event']}</td>";
        echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='guest'>{$row['guest']}</td>";
        echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='mobile'>{$row['mobile']}</td>";
        echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='relation'>{$row['relation']}</td>";
        echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='address'>{$row['address']}</td>";
        echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='gift'>{$row['gift']}</td>";
        echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='cash'>{$row['cash']}</td>";
        echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='mode'>{$row['mode']}</td>";
        echo "<td>{$row['created_at']}</td>";
        echo "</tr>";
    }
    ?>
</table>

<!-- Inline Edit & Filtering Scripts -->
<script>
    $(document).ready(function(){
        // Inline editing
        $('.editable').blur(function(){
            var id = $(this).data('id');
            var column = $(this).data('column');
            var value = $(this).text();

            $.post('update_entry.php', {
                id: id,
                column: column,
                value: value
            }, function(response){
                console.log(response);
            });
        });

        // Apply filters
        function applyFilters() {
            var guestVal = $('#filterGuest').val().toLowerCase();
            var modeVal = $('#filterMode').val().toLowerCase();
            var relationVal = $('#filterRelation').val().toLowerCase();
            var minCash = parseFloat($('#minCash').val());
            var maxCash = parseFloat($('#maxCash').val());

            $("#entryTable tr").each(function(index) {
                if (index === 0) return; // Skip header

                var row = $(this);
                var guest = row.find("td[data-column='guest']").text().toLowerCase();
                var mode = row.find("td[data-column='mode']").text().toLowerCase();
                var relation = row.find("td[data-column='relation']").text().toLowerCase();
                var cash = parseFloat(row.find("td[data-column='cash']").text()) || 0;

                var match = true;

                if (guestVal && !guest.includes(guestVal)) match = false;
                if (modeVal && mode !== modeVal) match = false;
                if (relationVal && relation !== relationVal) match = false;
                if (!isNaN(minCash) && cash < minCash) match = false;
                if (!isNaN(maxCash) && cash > maxCash) match = false;

                row.toggle(match);
            });
        }

        $('#filterGuest, #filterMode, #filterRelation, #minCash, #maxCash').on("input change", applyFilters);
    });
</script>

</body>
</html>
