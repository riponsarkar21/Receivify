<?php
require_once 'auth.php';
require_once 'db.php'; // Ensure this connects $mysqli
?>
<!DOCTYPE html>
<html>
<head>
    <title>Receivify</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="style.css"> -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<?php include 'header.php'; ?>

<form action="add_entry.php" method="POST">
    <label>Event Name:
        <input type="text" name="event" value="Ripon Akhi Wedding" required>
    </label><br>

    <label>Guest Name:
        <input type="text" name="guest" required>
    </label><br>

    <label>Mobile Number:
        <input type="tel" name="mobile" pattern="[0-9]{11}" placeholder="e.g. 017xxxxxxxx" required>
    </label><br>

    <label>Relation:
        <input type="text" name="relation" placeholder="e.g. Cousin, Friend, Uncle">
    </label><br>

    <label>Address:
        <input type="text" name="address">
    </label><br>

    <label>Gift Description:
        <input type="text" name="gift">
    </label><br>

    <label>Cash Amount:
        <input type="number" name="cash" min="0">
    </label><br>

    <label>Mode of Giving:
        <select name="mode">
            <option value="In-person">In-person</option>
            <option value="Online">Online</option>
            <option value="Proxy">Proxy</option>
        </select>
    </label><br>

    <button type="submit">Add Entry</button>
</form>

<h2>Gift/Cash Entries</h2>

<input type="text" id="searchInput" placeholder="Search entries..." style="width:100%; padding:8px; margin:10px 0;">

<div id="filters" style="margin-bottom: 15px; display: flex; flex-wrap: wrap; gap: 10px;">
    <input type="text" id="filterGuest" placeholder="Filter by guest name..." style="flex: 1;">

    <select id="filterMode">
        <option value="">All Modes</option>
        <option value="In-person">In-person</option>
        <option value="Online">Online</option>
        <option value="Proxy">Proxy</option>
    </select>

    <select id="filterRelation">
        <option value="">All Relations</option>
        <?php
        $relations = $mysqli->query("SELECT DISTINCT relation FROM entries WHERE relation IS NOT NULL AND relation != '' ORDER BY relation ASC");
        while ($rel = $relations->fetch_assoc()) {
            $relationVal = htmlspecialchars($rel['relation']);
            echo "<option value=\"{$relationVal}\">{$relationVal}</option>";
        }
        ?>
    </select>

    <input type="number" id="minCash" placeholder="Min cash" style="width: 100px;">
    <input type="number" id="maxCash" placeholder="Max cash" style="width: 100px;">
</div>

<div style="margin-bottom: 10px;">
    <a href="export_excel.php" target="_blank"><button type="button" style="width: 100px;">Export to Excel</button></a>
    <a href="export_pdf.php" target="_blank"><button type="button" style="width: 100px;">Export to PDF</button></a>
</div>

<table border="1" id="entryTable" style="width: 100%; border-collapse: collapse;">
    <thead>
        <tr>
            <th>Event</th>
            <th>Guest</th>
            <th>Mobile</th>
            <th>Relation</th>
            <th>Address</th>
            <th>Gift</th>
            <th>Cash</th>
            <th>Mode</th>
            <th>Time</th>
        </tr>
    </thead>
    <tbody>
    <?php
    $result = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='event'>" . htmlspecialchars($row['event']) . "</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='guest'>" . htmlspecialchars($row['guest']) . "</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='mobile'>" . htmlspecialchars($row['mobile']) . "</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='relation'>" . htmlspecialchars($row['relation']) . "</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='address'>" . htmlspecialchars($row['address']) . "</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='gift'>" . htmlspecialchars($row['gift']) . "</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='cash'>" . htmlspecialchars($row['cash']) . "</td>";
            echo "<td contenteditable='true' class='editable' data-id='{$row['id']}' data-column='mode'>" . htmlspecialchars($row['mode']) . "</td>";
            echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='9'>No entries found.</td></tr>";
    }
    ?>
    </tbody>
</table>

<script>
$(document).ready(function() {
    // Inline editing
    $('.editable').blur(function() {
        var id = $(this).data('id');
        var column = $(this).data('column');
        var value = $(this).text();

        $.post('update_entry.php', {
            id: id,
            column: column,
            value: value
        }, function(response) {
            console.log(response);
        });
    });

    // Search
    $("#searchInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#entryTable tbody tr").each(function() {
            var rowText = $(this).text().toLowerCase();
            $(this).toggle(rowText.indexOf(value) > -1);
        });
    });

    // Filters
    function applyFilters() {
        var guestVal = $('#filterGuest').val().toLowerCase();
        var modeVal = $('#filterMode').val().toLowerCase();
        var relationVal = $('#filterRelation').val().toLowerCase();
        var minCash = parseFloat($('#minCash').val());
        var maxCash = parseFloat($('#maxCash').val());

        $("#entryTable tbody tr").each(function() {
            var row = $(this);
            var guest = row.find("td[data-column='guest']").text().toLowerCase();
            var mode = row.find("td[data-column='mode']").text().toLowerCase();
            var relation = row.find("td[data-column='relation']").text().toLowerCase();
            var cash = parseFloat(row.find("td[data-column='cash']").text()) || 0;

            var match = true;
            if (guestVal && !guest.includes(guestVal)) match = false;
            if (modeVal && mode !== modeVal) match = false;
            if (relationVal && relation !== relationVal) match = false;
            if (!isNaN(minCash) && cash < minCash) match = false;
            if (!isNaN(maxCash) && cash > maxCash) match = false;

            row.toggle(match);
        });
    }

    $('#filterGuest, #filterMode, #filterRelation, #minCash, #maxCash').on("input change", applyFilters);
});
</script>

<?php include 'footer.php'; ?>
</body>
</html>
