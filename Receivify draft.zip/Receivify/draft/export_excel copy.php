<?php
$mysqli = new mysqli("localhost", "root", "", "receivify");
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=receivify_export.xls");

echo "Event\tGuest\tGift\tCash\tMode\tTime\n";

$result = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
while ($row = $result->fetch_assoc()) {
    echo "{$row['event']}\t{$row['guest']}\t{$row['gift']}\t{$row['cash']}\t{$row['mode']}\t{$row['created_at']}\n";
}
?>
