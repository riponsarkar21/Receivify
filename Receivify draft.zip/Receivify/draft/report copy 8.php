<?php
// report.php
session_start();
$mysqli = new mysqli("localhost", "root", "", "receivify");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
?>

<?php  include 'header.php' ?>

<!DOCTYPE html>
<html>
<head>
    <title>Report - Receivify</title>
    <meta charset="UTF-8">
    <!-- <link rel="stylesheet" href="style.css"> -->
   <style>
    
</style>

</head>
<body>

    <h1 style="text-align:center;">Report</h1>

    <div class="controls">
        <div class="filters">
            <input type="text" id="filterGuest" placeholder="Filter by guest">
            <select id="filterMode">
                <option value="">All Modes</option>
                <option value="In-person">In-person</option>
                <option value="Online">Online</option>
                <option value="Proxy">Proxy</option>
            </select>
            <select id="filterRelation">
                <option value="">All Relations</option>
                <?php
                $relations = $mysqli->query("SELECT DISTINCT relation FROM entries WHERE relation != '' ORDER BY relation ASC");
                while ($rel = $relations->fetch_assoc()) {
                    echo "<option value='{$rel['relation']}'>{$rel['relation']}</option>";
                }
                ?>
            </select>
            <input type="number" id="minCash" placeholder="Min cash">
            <input type="number" id="maxCash" placeholder="Max cash">
            <input type="date" id="startDate">
            <input type="date" id="endDate">
            <button id="clearFilters">Clear Filters</button>
        </div>

        <div class="export-buttons">
            <button onclick="exportFiltered('excel')">Export Excel</button>
            <button onclick="exportFiltered('csv')">Export CSV</button>
            <button onclick="exportFiltered('pdf')">Export PDF</button>
            <button onclick="window.print()">Print</button>
        </div>
    </div>

    <div class="filter-summary" style="margin-bottom:10px; font-style: italic; color: #555;"></div>

    <div id="rowsControl" style="margin-bottom:10px;">
        Show rows:
        <select id="rowsPerPage">
            <option>2</option>
            <option>5</option>
            <option selected>10</option>
            <option>25</option>
            <option>100</option>
            <option>1000</option>
            <option value="all">All</option>
        </select>
    </div>

    <table id="entryTable" border="1">
        <thead>
            <tr>
                <th class="sortable">Event</th>
                <th class="sortable">Guest</th>
                <th>Mobile</th>
                <th class="sortable">Relation</th>
                <th>Address</th>
                <th>Gift</th>
                <th class="sortable">Cash</th>
                <th class="sortable">Mode</th>
                <th class="sortable">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $entries = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
            $totalCash = 0;
            while ($row = $entries->fetch_assoc()) {
                $totalCash += $row['cash'];
                echo "<tr>";
                echo "<td>{$row['event']}</td>";
                echo "<td>{$row['guest']}</td>";
                echo "<td>{$row['mobile']}</td>";
                echo "<td>{$row['relation']}</td>";
                echo "<td>{$row['address']}</td>";
                echo "<td>{$row['gift']}</td>";
                echo "<td class='cash'>{$row['cash']}</td>";
                echo "<td>{$row['mode']}</td>";
                echo "<td>{$row['created_at']}</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6" style="text-align:right;"><strong>Total Cash:</strong></td>
                <td colspan="3"><strong id="cashTotal"><?php echo number_format($totalCash, 2); ?></strong></td>
            </tr>
        </tfoot>
    </table>

    <div id="pagination" style="margin-top: 15px; text-align: center;"></div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function applyFilters() {
            var guest = $('#filterGuest').val().toLowerCase();
            var mode = $('#filterMode').val().toLowerCase();
            var relation = $('#filterRelation').val().toLowerCase();
            var minCash = parseFloat($('#minCash').val()) || 0;
            var maxCash = parseFloat($('#maxCash').val()) || Infinity;
            var start = $('#startDate').val();
            var end = $('#endDate').val();

            $('.filter-summary').html('');

            let summary = [];

            $('#entryTable tbody tr').each(function() {
                var tds = $(this).find('td');
                var cash = parseFloat(tds.eq(6).text()) || 0;
                var created = tds.eq(8).text().slice(0, 10); // YYYY-MM-DD

                var show = true;
                if (guest && !tds.eq(1).text().toLowerCase().includes(guest)) show = false;
                if (mode && tds.eq(7).text().toLowerCase() !== mode) show = false;
                if (relation && tds.eq(3).text().toLowerCase() !== relation) show = false;
                if (cash < minCash || cash > maxCash) show = false;
                if (start && created < start) show = false;
                if (end && created > end) show = false;

                $(this).toggle(show);
            });

            updatePagination();
        }

        function updatePagination() {
            var perPage = $('#rowsPerPage').val();
            var rows = $('#entryTable tbody tr:visible');
            var total = rows.length;

            if (perPage === 'all') {
                rows.show();
                $('#pagination').empty();
                return;
            }

            perPage = parseInt(perPage);
            var pages = Math.ceil(total / perPage);
            var current = 1;

            function showPage(page) {
                rows.hide();
                rows.slice((page - 1) * perPage, page * perPage).show();
                current = page;
                renderPagination();
            }

        function renderPagination() {
            var html = '';

            // Previous button
            if (current > 1) {
                html += `<button onclick="showPage(${current - 1})">Previous</button> `;
            } else {
                html += `<button disabled>Previous</button> `;
            }

            // Page number buttons
            for (let i = 1; i <= pages; i++) {
                html += `<button onclick="showPage(${i})" ${i === current ? 'style="font-weight:bold;"' : ''}>${i}</button> `;
            }

            // Next button
            if (current < pages) {
                html += `<button onclick="showPage(${current + 1})">Next</button>`;
            } else {
                html += `<button disabled>Next</button>`;
            }

            $('#pagination').html(html);
        }


            window.showPage = showPage;
            showPage(1);
        }

        function exportFiltered(type) {
            alert("Filtered export for " + type + " not implemented in this mockup.");
        }

        $(function() {
            applyFilters();

            $('#filterGuest, #filterMode, #filterRelation, #minCash, #maxCash, #startDate, #endDate, #rowsPerPage').on('input change', applyFilters);
            $('#clearFilters').click(function(){
                $('.filters input, .filters select').not('#rowsPerPage').val('');

                applyFilters();
            });

            // Sorting
            $('th.sortable').click(function() {
                var idx = $(this).index();
                var rows = $('#entryTable tbody tr').get();

                var asc = !$(this).hasClass('sorted-asc');
                $('th').removeClass('sorted-asc sorted-desc');

                rows.sort(function(a, b) {
                    var A = $(a).children().eq(idx).text().toUpperCase();
                    var B = $(b).children().eq(idx).text().toUpperCase();
                    return asc ? A.localeCompare(B) : B.localeCompare(A);
                });

                $.each(rows, function(i, row) {
                    $('#entryTable tbody').append(row);
                });

                $(this).addClass(asc ? 'sorted-asc' : 'sorted-desc');
            });
        });
    </script>

<?php  include 'footer.php' ?>

</body>
</html>
