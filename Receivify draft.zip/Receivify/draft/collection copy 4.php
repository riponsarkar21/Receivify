<?php
require_once 'auth.php';
require_once 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Receivify - Collection</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_collection.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<?php include 'header.php'; ?>

<button type="button" id="addCollectionBtn">Add Collection</button>

<div id="entryModal">
    <div class="modal-content">
        <span id="closeModal">&times;</span>
        <h2>Add Entry</h2>
        <form action="add_entry.php" method="POST">
            <input type="hidden" name="event" value="Ripon Akhi Wedding">
            <label>Guest Name:
                <input type="text" name="guest" required>
            </label>
            <label>Mobile Number:
                <input type="tel" name="mobile" pattern="[0-9]{11}" placeholder="e.g. 017xxxxxxxx" required>
            </label>
            <label>Relation:
                <input type="text" name="relation" placeholder="e.g. Cousin, Friend, Uncle">
            </label>
            <label>Address:
                <input type="text" name="address">
            </label>
            <label>Gift Description:
                <input type="text" name="gift">
            </label>
            <label>Cash Amount:
                <input type="number" name="cash" min="0">
            </label>
            <label>Mode of Giving:
                <select name="mode">
                    <option value="In-person">In-person</option>
                    <option value="Online">Online</option>
                    <option value="Proxy">Proxy</option>
                </select>
            </label>
            <button type="submit">Submit</button>
        </form>
    </div>
</div>

<input type="text" id="searchInput" placeholder="Search entries...">

<div id="filters">
    <input type="text" id="filterGuest" placeholder="Filter by guest name...">
    <select id="filterMode">
        <option value="">All Modes</option>
        <option value="In-person">In-person</option>
        <option value="Online">Online</option>
        <option value="Proxy">Proxy</option>
    </select>
    <select id="filterRelation">
        <option value="">All Relations</option>
        <?php
        $relations = $mysqli->query("SELECT DISTINCT relation FROM entries WHERE relation IS NOT NULL AND relation != '' ORDER BY relation ASC");
        while ($rel = $relations->fetch_assoc()) {
            $relationVal = htmlspecialchars($rel['relation']);
            echo "<option value=\"{$relationVal}\">{$relationVal}</option>";
        }
        ?>
    </select>
    <input type="number" id="minCash" placeholder="Min cash">
    <input type="number" id="maxCash" placeholder="Max cash">
</div>

<div class="export-buttons">
    <a href="export_excel.php" target="_blank"><button type="button">Export to Excel</button></a>
    <a href="export_pdf.php" target="_blank"><button type="button">Export to PDF</button></a>
</div>

<table id="entryTable">
    <thead>
        <tr>
            <th>ID</th>
            <th>Guest</th>
            <th>Mobile</th>
            <th>Relation</th>
            <th>Address</th>
            <th>Gift</th>
            <th>Cash</th>
            <th>Mode</th>
            <th>Time</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $result = $mysqli->query("SELECT * FROM entries ORDER BY created_at DESC");
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $isCanceled = $row['is_canceled'] ? 'Canceled' : '';
                $canEdit = $_SESSION['role'] === 'admin' || $_SESSION['username'] === $row['created_by'];
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td contenteditable='" . ($canEdit ? 'true' : 'false') . "' class='editable' data-id='{$row['id']}' data-column='guest'>" . htmlspecialchars($row['guest']) . "</td>";
                echo "<td contenteditable='" . ($canEdit ? 'true' : 'false') . "' class='editable' data-id='{$row['id']}' data-column='mobile'>" . htmlspecialchars($row['mobile']) . "</td>";
                echo "<td contenteditable='" . ($canEdit ? 'true' : 'false') . "' class='editable' data-id='{$row['id']}' data-column='relation'>" . htmlspecialchars($row['relation']) . "</td>";
                echo "<td contenteditable='" . ($canEdit ? 'true' : 'false') . "' class='editable' data-id='{$row['id']}' data-column='address'>" . htmlspecialchars($row['address']) . "</td>";
                echo "<td contenteditable='" . ($canEdit ? 'true' : 'false') . "' class='editable' data-id='{$row['id']}' data-column='gift'>" . htmlspecialchars($row['gift']) . "</td>";
                echo "<td contenteditable='" . ($canEdit ? 'true' : 'false') . "' class='editable' data-id='{$row['id']}' data-column='cash'>" . htmlspecialchars($row['cash']) . "</td>";
                echo "<td contenteditable='" . ($canEdit ? 'true' : 'false') . "' class='editable' data-id='{$row['id']}' data-column='mode'>" . htmlspecialchars($row['mode']) . "</td>";
                echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
                echo "<td>$isCanceled</td>";
                echo "<td>";
                if ($canEdit) {
                    echo "<button class='cancel-btn' data-id='{$row['id']}'>Cancel</button> ";
                }
                if ($_SESSION['role'] === 'admin') {
                    echo "<button class='delete-btn' data-id='{$row['id']}'>Delete</button>";
                }
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='11'>No entries found.</td></tr>";
        }
        ?>
    </tbody>
</table>

<script>
$(document).ready(function() {
    // Inline Editing
    $('.editable').blur(function() {
        var id = $(this).data('id');
        var column = $(this).data('column');
        var value = $(this).text();

        $.post('update_entry.php', {
            id: id,
            column: column,
            value: value
        }, function(response) {
            console.log(response);
        });
    });

    // Cancel Button
    $(document).on('click', '.cancel-btn', function () {
        var id = $(this).data('id');
        if (confirm("Are you sure to cancel this entry?")) {
            $.post("cancel_entry.php", { id: id }, function (response) {
                alert("Entry canceled");
                location.reload();
            });
        }
    });

    // Delete Button
    $(document).on('click', '.delete-btn', function () {
        var id = $(this).data('id');
        if (confirm("Are you sure to delete this entry permanently?")) {
            $.post("delete_entry.php", { id: id }, function (response) {
                alert("Entry deleted");
                location.reload();
            });
        }
    });

    // Search
    $("#searchInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#entryTable tbody tr").each(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });

    // Filters
    function applyFilters() {
        var guestVal = $('#filterGuest').val().toLowerCase();
        var modeVal = $('#filterMode').val().toLowerCase();
        var relationVal = $('#filterRelation').val().toLowerCase();
        var minCash = parseFloat($('#minCash').val());
        var maxCash = parseFloat($('#maxCash').val());

        $("#entryTable tbody tr").each(function() {
            var guest = $(this).find("td[data-column='guest']").text().toLowerCase();
            var mode = $(this).find("td[data-column='mode']").text().toLowerCase();
            var relation = $(this).find("td[data-column='relation']").text().toLowerCase();
            var cash = parseFloat($(this).find("td[data-column='cash']").text()) || 0;

            var match = true;
            if (guestVal && !guest.includes(guestVal)) match = false;
            if (modeVal && mode !== modeVal) match = false;
            if (relationVal && relation !== relationVal) match = false;
            if (!isNaN(minCash) && cash < minCash) match = false;
            if (!isNaN(maxCash) && cash > maxCash) match = false;

            $(this).toggle(match);
        });
    }

    $('#filterGuest, #filterMode, #filterRelation, #minCash, #maxCash').on("input change", applyFilters);

    // Modal controls
    $("#addCollectionBtn").click(function() {
        $("#entryModal").fadeIn().css("display", "flex");
    });

    $("#closeModal").click(function() {
        $("#entryModal").fadeOut();
    });

    $("#entryModal").click(function(e) {
        if (e.target === this) {
            $(this).fadeOut();
        }
    });
});
</script>

<?php include 'footer.php'; ?>
</body>
</html>
