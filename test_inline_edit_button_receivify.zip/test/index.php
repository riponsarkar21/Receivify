<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Receivify</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
    <div class="container">
        <h2 class="mb-4">Guest Gift Entries</h2>

        <button class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#entryModal" onclick="resetForm()">Add Entry</button>

        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>ID</th><th>Event</th><th>Guest</th><th>Gift</th><th>Cash</th><th>Mode</th><th>Mobile</th><th>Relation</th><th>Address</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $db->query("SELECT * FROM full_texts WHERE is_canceled = 0");
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)):
                ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['event'] ?></td>
                        <td><?= $row['guest'] ?></td>
                        <td><?= $row['gift'] ?></td>
                        <td><?= $row['cash'] ?></td>
                        <td><?= $row['mode'] ?></td>
                        <td><?= $row['mobile'] ?></td>
                        <td><?= $row['relation'] ?></td>
                        <td><?= $row['address'] ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning" 
                                onclick='editEntry(<?= json_encode($row) ?>)'
                                data-bs-toggle="modal" data-bs-target="#entryModal">Edit</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Entry Modal -->
    <div class="modal fade" id="entryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <form method="POST" action="add_edit.php">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add/Edit Entry</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body row g-3">
                        <input type="hidden" name="id" id="id">
                        <div class="col-md-6"><input class="form-control" name="event" id="event" placeholder="Event" required></div>
                        <div class="col-md-6"><input class="form-control" name="guest" id="guest" placeholder="Guest" required></div>
                        <div class="col-md-4"><input class="form-control" name="gift" id="gift" placeholder="Gift"></div>
                        <div class="col-md-4"><input class="form-control" name="cash" id="cash" placeholder="Cash" type="number" step="0.01"></div>
                        <div class="col-md-4">
                            <select class="form-control" name="mode" id="mode">
                                <option>In-person</option>
                                <option>Online</option>
                            </select>
                        </div>
                        <div class="col-md-4"><input class="form-control" name="mobile" id="mobile" placeholder="Mobile"></div>
                        <div class="col-md-4"><input class="form-control" name="relation" id="relation" placeholder="Relation"></div>
                        <div class="col-md-4"><input class="form-control" name="address" id="address" placeholder="Address"></div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Entry</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function editEntry(data) {
    document.getElementById("id").value = data.id;
    document.getElementById("event").value = data.event;
    document.getElementById("guest").value = data.guest;
    document.getElementById("gift").value = data.gift;
    document.getElementById("cash").value = data.cash;
    document.getElementById("mode").value = data.mode;
    document.getElementById("mobile").value = data.mobile;
    document.getElementById("relation").value = data.relation;
    document.getElementById("address").value = data.address;
}

function resetForm() {
    document.querySelector("form").reset();
    document.getElementById("id").value = "";
}
</script>
</body>
</html>
