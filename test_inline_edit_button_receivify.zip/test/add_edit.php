<?php
include 'db.php';

$id = $_POST['id'] ?? '';
$data = [
    'event' => $_POST['event'],
    'guest' => $_POST['guest'],
    'gift' => $_POST['gift'],
    'cash' => $_POST['cash'],
    'mode' => $_POST['mode'],
    'mobile' => $_POST['mobile'],
    'relation' => $_POST['relation'],
    'address' => $_POST['address']
];

if ($id) {
    // Update
    $data['id'] = $id;
    $sql = "UPDATE full_texts SET 
                event = :event,
                guest = :guest,
                gift = :gift,
                cash = :cash,
                mode = :mode,
                mobile = :mobile,
                relation = :relation,
                address = :address,
                updated_at = NOW()
            WHERE id = :id";
} else {
    // Insert
    $sql = "INSERT INTO full_texts (
                event, guest, gift, cash, mode, mobile, relation, address, created_at, is_canceled, status
            ) VALUES (
                :event, :guest, :gift, :cash, :mode, :mobile, :relation, :address, NOW(), 0, 'Active'
            )";
}

$stmt = $db->prepare($sql);
$stmt->execute($data);

header("Location: index.php");
exit;
?>
