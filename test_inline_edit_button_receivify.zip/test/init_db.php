<?php
$host = 'localhost';
$dbname = 'test';
$user = 'root';
$pass = ''; // default for XAMPP

try {
    // Connect to MySQL server without selecting a DB
    $pdo = new PDO("mysql:host=$host", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create database if it doesn't exist
    $pdo->exec("CREATE DATABASE IF NOT EXISTS $dbname");
    echo "✅ Database '$dbname' created or already exists.<br>";

    // Connect to the newly created database
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create the table
    $sql = "
        CREATE TABLE IF NOT EXISTS full_texts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            event VARCHAR(255),
            guest VARCHAR(255),
            gift VARCHAR(255),
            cash DECIMAL(10,2),
            mode VARCHAR(100),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            mobile VARCHAR(20),
            relation VARCHAR(100),
            address VARCHAR(255),
            created_by VARCHAR(100),
            last_edited_by VARCHAR(100),
            last_edited_at DATETIME DEFAULT NULL,
            canceled_by VARCHAR(100),
            canceled_at DATETIME DEFAULT NULL,
            is_canceled TINYINT(1) DEFAULT 0,
            status VARCHAR(50) DEFAULT 'Active'
        );
    ";
    $pdo->exec($sql);
    echo "✅ Table 'full_texts' created or already exists.<br>";

} catch (PDOException $e) {
    die("❌ Error: " . $e->getMessage());
}
?>
