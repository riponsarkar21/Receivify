-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 15, 2025 at 01:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `full_texts`
--

CREATE TABLE `full_texts` (
  `id` int(11) NOT NULL,
  `event` varchar(255) DEFAULT NULL,
  `guest` varchar(255) DEFAULT NULL,
  `gift` varchar(255) DEFAULT NULL,
  `cash` decimal(10,2) DEFAULT NULL,
  `mode` varchar(100) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `mobile` varchar(20) DEFAULT NULL,
  `relation` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `last_edited_by` varchar(100) DEFAULT NULL,
  `last_edited_at` datetime DEFAULT NULL,
  `canceled_by` varchar(100) DEFAULT NULL,
  `canceled_at` datetime DEFAULT NULL,
  `is_canceled` tinyint(1) DEFAULT 0,
  `status` varchar(50) DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `full_texts`
--

INSERT INTO `full_texts` (`id`, `event`, `guest`, `gift`, `cash`, `mode`, `created_at`, `updated_at`, `mobile`, `relation`, `address`, `created_by`, `last_edited_by`, `last_edited_at`, `canceled_by`, `canceled_at`, `is_canceled`, `status`) VALUES
(1, 'Wedding', 'Ripon', 'Sharee', 1000.00, 'Online', '2025-06-15 05:08:26', '2025-06-15 05:08:37', '01928078420', 'Brother', 'Jessore', NULL, NULL, NULL, NULL, NULL, 0, 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `full_texts`
--
ALTER TABLE `full_texts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `full_texts`
--
ALTER TABLE `full_texts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
